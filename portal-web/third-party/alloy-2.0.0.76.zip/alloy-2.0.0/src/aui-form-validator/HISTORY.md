AUI Form Validator
========

@VERSION@
------
	* [AUI-2038](https://issues.liferay.com/browse/AUI-2038) UI should alert about non-unique value in structure field of type Select.
	* [AUI-2037](https://issues.liferay.com/browse/AUI-2037) validateField() does not reset error states for fields no longer in the DOM, preventing form submission
	* #AUI-2043 Make required rule the default error message when showAllMessages is false.
	* #AUI-2027 Allow requiring custom validation without field values
	* #AUI-2040 Change validation for file input on change event
	* #AUI-1585 aui-form-validator error breaks radio button layout

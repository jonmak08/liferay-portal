AUI Data Type
========

@VERSION@
------

	* #AUI-978 DateParser is returning the current date when the parsing fails

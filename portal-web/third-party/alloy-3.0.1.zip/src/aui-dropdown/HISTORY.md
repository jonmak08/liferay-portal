# AUI Dropdown

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-dropdown).

## @VERSION@

No registries yet.

## [3.0.1](https://github.com/liferay/alloy-ui/releases/tag/3.0.1)

No changes.

## [3.0.0](https://github.com/liferay/alloy-ui/releases/tag/3.0.0)

* [AUI-1820](https://issues.liferay.com/browse/AUI-1820) Form Builder is not keyboard-accessible
* [AUI-1377](https://issues.liferay.com/browse/AUI-1377) AUI-Dropdown tests fail on IE8
* [AUI-1153](https://issues.liferay.com/browse/AUI-1153) Create Bootstrap's Dropdown module

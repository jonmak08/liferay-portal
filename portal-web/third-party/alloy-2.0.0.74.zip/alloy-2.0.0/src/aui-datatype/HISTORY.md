# AUI DataType

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-datatype).

## @VERSION@

	* #AUI-2061 Low performance on countDays method when using huge dates.
	* #AUI-1864 Method "countDays()" created to get the whole number of days between two dates.
	* #AUI-978 DateParser is returning the current date when the parsing fails

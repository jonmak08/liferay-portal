AUI Form Validator
========

@VERSION@
------

	* #AUI-2027 Allow requiring custom validation without field values
	* #AUI-2040 Change validation for file input on change event
	* #AUI-1585 aui-form-validator error breaks radio button layout
	* #AUI-965 Fixed issue with select box items and displaying error messages
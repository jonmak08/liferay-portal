AUI Form Validator
========

@VERSION@
------

	* #AUI-2043 Make required rule the default error message when showAllMessages is false.
	* #AUI-2027 Allow requiring custom validation without field values
	* #AUI-2040 Change validation for file input on change event
	* #AUI-1585 aui-form-validator error breaks radio button layout

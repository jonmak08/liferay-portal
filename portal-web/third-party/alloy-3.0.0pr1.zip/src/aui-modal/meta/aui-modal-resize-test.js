function(A) {
    return !A.UA.mobile;
}

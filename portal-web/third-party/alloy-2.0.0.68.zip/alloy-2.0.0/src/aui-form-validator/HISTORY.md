AUI Form Validator
========

@VERSION@
------

	* #AUI-2040 Change validation for file input on change event
	* #AUI-1958 When custom and default validators are used together the validators show errors without setting a value in the field
	* #AUI-1585 aui-form-validator error breaks radio button layout
	* #AUI-965 Fixed issue with select box items and displaying error messages